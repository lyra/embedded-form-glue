import type { KryptonGlueLoadParameter } from './types';
export type KRGlue = Glue;
declare class Glue {
    #private;
    readonly _name = "Krypton Glue";
    private static instance;
    private configuration;
    private loaded;
    private loading;
    private loadedPublicKey;
    constructor();
    /**
     * Set or update configuration used by subsequent glue calls. Omitted values remain unchanged;
     * explicitly passing `null` clears a value.
     *
     * @param opts - Configuration values to update.
     *
     * @example
     *    await KRGlue.load({
     *      domain: 'https://domain.name',
     *      publicKey: '12345678:publickey_abcdefghi...',
     *      formToken: 'FORM-TOKEN',
     *      theme: 'neon'
     *    })
     */
    load(opts: KryptonGlueLoadParameter): Promise<{
        KR: KR;
    }>;
}
declare const _default: Glue;
export default _default;
